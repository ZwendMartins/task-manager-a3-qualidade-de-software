package com.taskmanager.backend.application;

import com.taskmanager.backend.application.port.in.CreateTaskUseCase;
import com.taskmanager.backend.application.port.in.UpdateTaskUseCase;
import com.taskmanager.backend.application.port.out.TaskEventPublisherPort;
import com.taskmanager.backend.application.port.out.TaskRepositoryPort;
import com.taskmanager.backend.domain.Task;
import com.taskmanager.backend.domain.TaskNotFoundException;
import com.taskmanager.backend.domain.TaskStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskApplicationServiceTest {

    @Mock
    private TaskRepositoryPort taskRepository;

    @Mock
    private TaskEventPublisherPort taskEventPublisher;

    @InjectMocks
    private TaskApplicationService service;

    private Task task(Long id, String title, TaskStatus status) {
        return new Task(
                id,
                title,
                "Description",
                status,
                Instant.parse("2026-01-01T10:00:00Z")
        );
    }

    @Test
    void createPersistsBeforePublishingCreatedEvent() {
        var command = new CreateTaskUseCase.CreateTaskCommand(
                "Title", "Description"
        );

        Task persisted = task(1L, "Title", TaskStatus.PENDING);

        when(taskRepository.save(any(Task.class))).thenReturn(persisted);

        Task result = service.create(command);

        assertThat(result).isEqualTo(persisted);

        InOrder order = inOrder(taskRepository, taskEventPublisher);

        order.verify(taskRepository).save(any(Task.class));
        order.verify(taskEventPublisher).publishTaskCreated(persisted);
    }

    @Test
    void updatePersistsAndPublishesUpdatedEvent() {
        Long id = 10L;

        Task existing = task(id, "Old", TaskStatus.PENDING);
        Task saved = task(id, "New", TaskStatus.DONE);

        when(taskRepository.findById(id))
                .thenReturn(Optional.of(existing));

        when(taskRepository.save(any(Task.class)))
                .thenReturn(saved);

        var command = new UpdateTaskUseCase.UpdateTaskCommand(
                "New",
                "New description",
                TaskStatus.DONE
        );

        Task result = service.update(id, command);

        assertThat(result).isEqualTo(saved);

        verify(taskRepository).save(argThat(t ->
                t.id().equals(id)
                        && t.title().equals("New")
                        && t.description().equals("New description")
                        && t.status() == TaskStatus.DONE
        ));

        verify(taskEventPublisher).publishTaskUpdated(saved);
    }

    @Test
    void updateMissingTaskThrowsWithoutSavingOrPublishing() {
        Long id = 404L;

        when(taskRepository.findById(id))
                .thenReturn(Optional.empty());

        var command = new UpdateTaskUseCase.UpdateTaskCommand(
                "New",
                "Description",
                TaskStatus.DONE
        );

        assertThatThrownBy(() -> service.update(id, command))
                .isInstanceOf(TaskNotFoundException.class);

        verify(taskRepository, never()).save(any());
        verify(taskEventPublisher, never()).publishTaskUpdated(any());
    }

    @Test
    void deleteExistingTaskDeletesIt() {
        Long id = 10L;

        when(taskRepository.findById(id))
                .thenReturn(Optional.of(
                        task(id, "Title", TaskStatus.PENDING)
                ));

        service.delete(id);

        verify(taskRepository).deleteById(id);
    }

    @Test
    void deleteMissingTaskThrowsWithoutDeleting() {
        Long id = 404L;

        when(taskRepository.findById(id))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.delete(id))
                .isInstanceOf(TaskNotFoundException.class);

        verify(taskRepository, never()).deleteById(any());
    }

    @Test
    void getByIdReturnsExistingTask() {
        Task expected = task(1L, "Title", TaskStatus.PENDING);

        when(taskRepository.findById(1L))
                .thenReturn(Optional.of(expected));

        assertThat(service.getById(1L)).isEqualTo(expected);
    }

    @Test
    void getByIdThrowsWhenTaskDoesNotExist() {
        when(taskRepository.findById(999L))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getById(999L))
                .isInstanceOf(TaskNotFoundException.class);
    }

    @Test
    void listReturnsTasksWhenRepositoryIsNotEmpty() {
        List<Task> expected = List.of(
                task(1L, "One", TaskStatus.PENDING),
                task(2L, "Two", TaskStatus.DONE)
        );

        when(taskRepository.findAll()).thenReturn(expected);

        assertThat(service.list())
                .containsExactlyElementsOf(expected);
    }

    @Test
    void listReturnsEmptyListWhenRepositoryIsEmpty() {
        when(taskRepository.findAll()).thenReturn(List.of());

        assertThat(service.list()).isEmpty();
    }
}