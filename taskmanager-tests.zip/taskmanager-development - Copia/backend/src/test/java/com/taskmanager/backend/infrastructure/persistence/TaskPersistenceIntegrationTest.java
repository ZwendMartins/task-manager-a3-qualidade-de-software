package com.taskmanager.backend.infrastructure.persistence;

import com.taskmanager.backend.domain.Task;
import com.taskmanager.backend.domain.TaskStatus;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import({
        JpaTaskRepositoryAdapter.class,
        TaskPersistenceMapper.class
})
@TestPropertySource(properties = {
        "spring.jpa.hibernate.ddl-auto=validate",
        "spring.liquibase.enabled=true"
})
class TaskPersistenceIntegrationTest {

    @Autowired
    private JpaTaskRepository repository;

    @Autowired
    private JpaTaskRepositoryAdapter repositoryAdapter;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // CB-10: verifica se uma atualização com uma versão antiga é identificada como conflito.
    @Test
    void updatingStaleTaskCopyShouldRaiseOptimisticLockingFailure() {
        TaskEntity initial = new TaskEntity();

        initial.setTitle("Initial title");
        initial.setDescription("Description");
        initial.setStatus(TaskStatus.PENDING);
        initial.setCreatedAt(
                Instant.parse("2026-01-01T10:00:00Z")
        );

        TaskEntity saved = repository.saveAndFlush(initial);
        Long id = saved.getId();

        entityManager.clear();

        TaskEntity firstCopy = repository.findById(id).orElseThrow();

        entityManager.clear();

        TaskEntity staleCopy = repository.findById(id).orElseThrow();

        firstCopy.setTitle("First update");
        repository.saveAndFlush(firstCopy);

        staleCopy.setTitle("Stale update");

        assertThatThrownBy(() -> repository.saveAndFlush(staleCopy))
                .isInstanceOf(OptimisticLockingFailureException.class);
    }

    // CB-11: verifica se o Liquibase criou o schema esperado e se a entidade persiste corretamente.
    @Test
    void liquibaseSchemaShouldMatchTaskEntityAndPersistTask() {
        Integer appliedChangesets = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM databasechangelog WHERE id = ?",
                Integer.class,
                "001-create-tasks-table"
        );

        assertThat(appliedChangesets).isEqualTo(1);

        Task task = new Task(
                null,
                "Liquibase test",
                "Persistence mapping test",
                TaskStatus.PENDING,
                Instant.parse("2026-01-01T10:00:00Z")
        );

        Task saved = repositoryAdapter.save(task);

        entityManager.flush();
        entityManager.clear();

        Task loaded = repositoryAdapter.findById(saved.id()).orElseThrow();

        assertThat(loaded.id()).isEqualTo(saved.id());
        assertThat(loaded.title()).isEqualTo("Liquibase test");
        assertThat(loaded.description()).isEqualTo("Persistence mapping test");
        assertThat(loaded.status()).isEqualTo(TaskStatus.PENDING);
        assertThat(loaded.createdAt()).isEqualTo(task.createdAt());
    }
}