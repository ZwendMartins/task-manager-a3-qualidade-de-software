import {
  afterEach,
  beforeEach,
  describe,
  expect,
  it,
  vi
} from 'vitest';

import {
  httpClient,
  setHttpErrorHandler
} from '../httpClient';

import { AppError } from '../appError';

describe('httpClient error normalization', () => {
  const onError = vi.fn();

  beforeEach(() => {
    setHttpErrorHandler(onError);
    vi.stubGlobal('fetch', vi.fn());
  });

  afterEach(() => {
    setHttpErrorHandler(() => undefined);
    vi.unstubAllGlobals();
  });

  it('normalizes 400 responses and preserves fieldErrors and code', async () => {
    vi.mocked(fetch).mockResolvedValue(
      new Response(JSON.stringify({
        detail: 'Existem campos invalidos.',
        code: 'VALIDATION_ERROR',
        fieldErrors: {
          title: 'Titulo obrigatorio.'
        }
      }), {
        status: 400,
        headers: {
          'Content-Type': 'application/json'
        }
      })
    );

    await expect(
      httpClient.post('/api/tasks', {
        title: '',
        description: 'x'
      })
    ).rejects.toMatchObject({
      statusCode: 400,
      code: 'VALIDATION_ERROR',
      fieldErrors: {
        title: 'Titulo obrigatorio.'
      }
    });

    expect(onError).toHaveBeenCalledWith(
      expect.any(AppError)
    );
  });

  it('normalizes 404 responses using the backend detail', async () => {
    vi.mocked(fetch).mockResolvedValue(
      new Response(JSON.stringify({
        detail: 'Task not found',
        code: 'TASK_NOT_FOUND'
      }), {
        status: 404
      })
    );

    await expect(
      httpClient.get('/api/tasks/99')
    ).rejects.toMatchObject({
      statusCode: 404,
      code: 'TASK_NOT_FOUND',
      message: 'Task not found'
    });
  });

  it('normalizes 500 responses even when the body is empty', async () => {
    vi.mocked(fetch).mockResolvedValue(
      new Response('', {
        status: 500
      })
    );

    await expect(
      httpClient.get('/api/tasks')
    ).rejects.toMatchObject({
      statusCode: 500,
      code: 'HTTP_ERROR',
      message: 'Falha interna no servidor.'
    });
  });

  it('normalizes network failures as NETWORK_ERROR', async () => {
    vi.mocked(fetch).mockRejectedValue(
      new TypeError('Failed to fetch')
    );

    await expect(
      httpClient.get('/api/tasks')
    ).rejects.toMatchObject({
      code: 'NETWORK_ERROR',
      message: 'Falha de conexao. Verifique se o backend esta disponivel.'
    });
  });

  it('returns undefined for a successful 204 response', async () => {
    vi.mocked(fetch).mockResolvedValue(
      new Response(null, {
        status: 204
      })
    );

    await expect(
      httpClient.delete('/api/tasks/1')
    ).resolves.toBeUndefined();
  });
});