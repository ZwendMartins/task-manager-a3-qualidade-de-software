
package com.taskmanager.backend.api;

import static org.hamcrest.Matchers.aMapWithSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Instant;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.taskmanager.backend.application.port.in.CreateTaskUseCase;
import com.taskmanager.backend.application.port.in.DeleteTaskUseCase;
import com.taskmanager.backend.application.port.in.GetTaskUseCase;
import com.taskmanager.backend.application.port.in.ListTasksUseCase;
import com.taskmanager.backend.application.port.in.UpdateTaskUseCase;
import com.taskmanager.backend.domain.Task;
import com.taskmanager.backend.domain.TaskNotFoundException;
import com.taskmanager.backend.domain.TaskStatus;

@WebMvcTest(TaskController.class)
@Import(GlobalExceptionHandler.class)
class TaskControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CreateTaskUseCase createTaskUseCase;

    @MockitoBean
    private ListTasksUseCase listTasksUseCase;

    @MockitoBean
    private GetTaskUseCase getTaskUseCase;

    @MockitoBean
    private UpdateTaskUseCase updateTaskUseCase;

    @MockitoBean
    private DeleteTaskUseCase deleteTaskUseCase;

   
    @Test
    void createShouldReturn201AndTaskPayload() throws Exception {
        Task task = new Task(
                1L, "Estudar Java", "Revisar conteúdo",
                TaskStatus.PENDING, Instant.now()
        );

        when(createTaskUseCase.create(any())).thenReturn(task);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Estudar Java",
                                    "description": "Revisar conteúdo"
                                }
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Estudar Java"))
                .andExpect(jsonPath("$.status").value("PENDING"));
    }

    @Test
    void createShouldReturnAllTaskResponseFields() throws Exception {
        Task task = new Task(
                1L, "Estudar Java", "Revisar conteúdo",
                TaskStatus.PENDING,
                Instant.parse("2026-11-16T10:00:00Z")
        );

        when(createTaskUseCase.create(any())).thenReturn(task);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Estudar Java",
                                    "description": "Revisar conteúdo"
                                }
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Estudar Java"))
                .andExpect(jsonPath("$.description").value("Revisar conteúdo"))
                .andExpect(jsonPath("$.status").value("PENDING"))
                .andExpect(jsonPath("$.createdAt").exists());
    }

    @Test
    void createShouldAcceptTitleWithExactly200Characters() throws Exception {
        String title = "a".repeat(200);

        Task task = new Task(
                1L, title, "Descrição válida",
                TaskStatus.PENDING, Instant.now()
        );

        when(createTaskUseCase.create(any())).thenReturn(task);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "%s",
                                    "description": "Descrição válida"
                                }
                                """.formatted(title)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value(title));
    }

    @Test
    void createShouldAcceptDescriptionWithExactly1000Characters() throws Exception {
        String description = "a".repeat(1000);

        Task task = new Task(
                1L, "Tarefa válida", description,
                TaskStatus.PENDING, Instant.now()
        );

        when(createTaskUseCase.create(any())).thenReturn(task);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Tarefa válida",
                                    "description": "%s"
                                }
                                """.formatted(description)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.description").value(description));
    }

    @Test
    void createShouldRejectTitleLongerThan200Characters() throws Exception {
        String title = "a".repeat(201);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "%s",
                                    "description": "Descrição válida"
                                }
                                """.formatted(title)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"))
                .andExpect(jsonPath("$.fieldErrors.title").exists());
    }

    @Test
    void createShouldRejectBlankDescription() throws Exception {
        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Tarefa válida",
                                    "description": "   "
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.description").exists());
    }

    @Test
    void createShouldRejectDescriptionLongerThan1000Characters() throws Exception {
        String description = "a".repeat(1001);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Tarefa válida",
                                    "description": "%s"
                                }
                                """.formatted(description)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.description").exists());
    }

    @Test
    void validationShouldReturnOnlyOneErrorForTitleWith201Spaces() throws Exception {
        String title = " ".repeat(201);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "%s",
                                    "description": "Descrição válida"
                                }
                                """.formatted(title)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"))
                .andExpect(jsonPath("$.fieldErrors", aMapWithSize(1)));
    }



    @Test
    void listShouldReturnTasks() throws Exception {
    Task task1 = new Task(
            1L,
            "Estudar Java",
            "Revisar testes unitários",
            TaskStatus.PENDING,
            Instant.parse("2026-01-01T10:00:00Z")
    );

    Task task2 = new Task(
            2L,
            "Fazer trabalho",
            "Finalizar atividade da faculdade",
            TaskStatus.DONE,
            Instant.parse("2026-01-02T10:00:00Z")
    );

    when(listTasksUseCase.list()).thenReturn(List.of(task1, task2));

    mockMvc.perform(get("/api/tasks"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.length()").value(2))
            .andExpect(jsonPath("$[0].title").value("Estudar Java"))
            .andExpect(jsonPath("$[1].title").value("Fazer trabalho"));
    }
    @Test
    void getByIdShouldReturnTaskWhenTaskExists() throws Exception {
        Task task = new Task(
                1L, "Estudar Java", "Revisar testes automatizados",
                TaskStatus.PENDING, Instant.now()
        );

        when(getTaskUseCase.getById(1L)).thenReturn(task);

        mockMvc.perform(get("/api/tasks/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Estudar Java"))
                .andExpect(jsonPath("$.description").value("Revisar testes automatizados"))
                .andExpect(jsonPath("$.status").value("PENDING"));
    }

    @Test
    void getByIdShouldReturn404WithProblemDetailContract() throws Exception {
        when(getTaskUseCase.getById(99L))
                .thenThrow(new TaskNotFoundException(99L));

        mockMvc.perform(get("/api/tasks/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("TASK_NOT_FOUND"))
                .andExpect(jsonPath("$.userSafe").value(true));
    }

    @Test
    void getByIdShouldReturnBadRequestWhenIdIsNotNumeric() throws Exception {
        mockMvc.perform(get("/api/tasks/abc"))
                .andExpect(status().isBadRequest());
    }

    // =====================================================
    // CP-03 / CP-08 - ATUALIZAÇÃO DE TAREFAS
    // =====================================================

    @Test
    void updateShouldReturnUpdatedTask() throws Exception {
        Task updatedTask = new Task(
                1L, "Estudar Spring Boot", "Revisar testes de integração",
                TaskStatus.PENDING, Instant.now()
        );

        when(updateTaskUseCase.update(eq(1L), any()))
                .thenReturn(updatedTask);

        mockMvc.perform(put("/api/tasks/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Estudar Spring Boot",
                                    "description": "Revisar testes de integração",
                                    "status": "PENDING"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Estudar Spring Boot"))
                .andExpect(jsonPath("$.description").value("Revisar testes de integração"))
                .andExpect(jsonPath("$.status").value("PENDING"));
    }

    @Test
    void updateShouldReturn400WithFieldErrorsWhenValidationFails() throws Exception {
        mockMvc.perform(put("/api/tasks/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": " ",
                                    "description": "Descrição válida",
                                    "status": null
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Validation error"))
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"))
                .andExpect(jsonPath("$.fieldErrors.title").exists())
                .andExpect(jsonPath("$.fieldErrors.status").exists());
    }

    @Test
    void updateShouldReturn404WhenTaskDoesNotExist() throws Exception {
        doThrow(new TaskNotFoundException(999L))
                .when(updateTaskUseCase)
                .update(eq(999L), any());

        mockMvc.perform(put("/api/tasks/999")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Nova tarefa",
                                    "description": "Descrição da tarefa",
                                    "status": "PENDING"
                                }
                                """))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("TASK_NOT_FOUND"));
    }


    @Test
    void deleteShouldReturn204() throws Exception {
        mockMvc.perform(delete("/api/tasks/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void deleteShouldReturn404WhenTaskDoesNotExist() throws Exception {
        doThrow(new TaskNotFoundException(500L))
                .when(deleteTaskUseCase).delete(500L);

        mockMvc.perform(delete("/api/tasks/500"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("TASK_NOT_FOUND"));
    }


    @Test
    void malformedJsonShouldReturnBadRequest() throws Exception {
        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"title\":"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void invalidStatusValueShouldReturnBadRequest() throws Exception {
        mockMvc.perform(put("/api/tasks/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "title": "Tarefa",
                                    "description": "Descrição",
                                    "status": "XYZ"
                                }
                                """))
                .andExpect(status().isBadRequest());
    }

    @Test
    void unexpectedExceptionShouldReturn500WithoutStackTrace() throws Exception {
        when(getTaskUseCase.getById(1L))
                .thenThrow(new IllegalStateException("Erro interno de teste"));

        mockMvc.perform(get("/api/tasks/1"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.code").value("UNEXPECTED_ERROR"))
                .andExpect(jsonPath("$.userSafe").value(true))
                .andExpect(jsonPath("$.stackTrace").doesNotExist())
                .andExpect(jsonPath("$.detail").value("Ocorreu um erro inesperado. Tente novamente."));
    }
}