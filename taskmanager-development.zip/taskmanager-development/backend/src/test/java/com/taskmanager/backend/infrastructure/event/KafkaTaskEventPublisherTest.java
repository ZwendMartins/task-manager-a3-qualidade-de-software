package com.taskmanager.backend.infrastructure.event;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.taskmanager.backend.domain.Task;
import com.taskmanager.backend.domain.TaskStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.mockito.ArgumentCaptor;

import java.time.Instant;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(OutputCaptureExtension.class)
class KafkaTaskEventPublisherTest {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @SuppressWarnings("unchecked")
    private final KafkaTemplate<String, String> kafkaTemplate =
            mock(KafkaTemplate.class);

    private final KafkaTaskEventPublisher publisher =
            new KafkaTaskEventPublisher(kafkaTemplate, "task-events");

    private Task task(String title, String description) {
        return new Task(
                7L,
                title,
                description,
                TaskStatus.PENDING,
                Instant.parse("2026-01-01T10:00:00Z")
        );
    }

    private String captureCreatedPayload(Task task) {
        when(kafkaTemplate.send(eq("task-events"), eq("7"), anyString()))
                .thenReturn(CompletableFuture.completedFuture(null));

        publisher.publishTaskCreated(task);

        ArgumentCaptor<String> payload =
                ArgumentCaptor.forClass(String.class);

        verify(kafkaTemplate).send(
                eq("task-events"),
                eq("7"),
                payload.capture()
        );

        return payload.getValue();
    }

    @Test
    void publishesCreatedEventWithTaskIdAsKeyAndEscapedJson() throws Exception {
        String payload = captureCreatedPayload(
                task("A \"title\"", "path \\ folder")
        );

        JsonNode json = OBJECT_MAPPER.readTree(payload);

        assertThat(json.get("eventType").asText())
                .isEqualTo("TASK_CREATED");

        assertThat(json.get("taskId").asLong())
                .isEqualTo(7L);

        assertThat(json.get("title").asText())
                .isEqualTo("A \"title\"");

        assertThat(json.get("description").asText())
                .isEqualTo("path \\ folder");
    }

    
    @Test
    void newlineAndTabInDescriptionShouldProduceValidJson() throws Exception {
        String payload = captureCreatedPayload(
                task("Title", "line one\nline two\tend")
        );

        JsonNode json = OBJECT_MAPPER.readTree(payload);

        assertThat(json.get("description").asText())
                .isEqualTo("line one\nline two\tend");
    }


    @Test
    void nullTitleAndDescriptionShouldBeSerializedAsEmptyStrings() throws Exception {
        String payload = captureCreatedPayload(task(null, null));

        JsonNode json = OBJECT_MAPPER.readTree(payload);

        assertThat(json.get("title").asText()).isEmpty();
        assertThat(json.get("description").asText()).isEmpty();
    }

    @Test
    void publishesUpdatedEvent() {
        when(kafkaTemplate.send(eq("task-events"), eq("7"), anyString()))
                .thenReturn(CompletableFuture.completedFuture(null));

        publisher.publishTaskUpdated(task("Updated", "Description"));

        verify(kafkaTemplate).send(
                eq("task-events"),
                eq("7"),
                argThat(json -> json.contains("\"eventType\":\"TASK_UPDATED\""))
        );
    }

   
    @Test
    void synchronousKafkaFailureIsSwallowedByPublisher() {
        when(kafkaTemplate.send(eq("task-events"), eq("7"), anyString()))
                .thenThrow(new IllegalStateException("Kafka unavailable"));

        assertDoesNotThrow(() ->
                publisher.publishTaskCreated(task("Title", "Description"))
        );
    }

    @Test
    void asynchronousKafkaFailureShouldBeLogged(CapturedOutput output) {
        when(kafkaTemplate.send(eq("task-events"), eq("7"), anyString()))
                .thenReturn(
                        CompletableFuture.failedFuture(
                                new IllegalStateException("Kafka unavailable")
                        )
                );

        assertDoesNotThrow(() ->
                publisher.publishTaskUpdated(task("Title", "Description"))
        );

        assertThat(output).contains("event_publish_failed");
    }
}
